package com.munna.dtodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtoDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
