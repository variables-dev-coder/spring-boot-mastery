package com.munna.springboot.day7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day7HelloApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day7HelloApiApplication.class, args);
	}

}
